"""
mistral_coach.py

Erstellt das finale Coach-Feedback mit Mistral.

Diese Schicht enthält ausschließlich
Prompt Building und den LLM-Aufruf.
"""

from __future__ import annotations

import json

from models.training_analysis import (
    TrainingAnalysis,
)

from prompts.coach import (
    COACH_PROMPT,
    DAILY_COACH_TIPS_PROMPT,
)

from services.mistral_service import (
    call_mistral,
)


def build_coach_with_mistral(
    *,
    coach_context: dict,
    sportart: str,
    level: str,
    injuries: str | None,
    api_key: str,
    model: str,
) -> dict[str, str]:
    """Erstellt eine modulare Coach-Einordnung aus deterministischen Fakten."""
    readiness_facts = coach_context.get("readiness_summary_facts", {})
    history_facts = coach_context.get("history_coach_facts", {})

    prompt = f"""
{COACH_PROMPT}

SPORTART: {sportart}
LEVEL: {level}
BESCHWERDEN: {injuries or "Keine"}

DETERMINISTISCHE COACH-FAKTEN
{json.dumps(history_facts, ensure_ascii=False, indent=2)}

READINESS-KURZFAKTEN
{json.dumps(readiness_facts, ensure_ascii=False, indent=2)}

AUFGABE
Erstelle eine kurze, modulare Coach-Einordnung. Die Analysewerte sind Fakten und dürfen
nicht neu berechnet oder umgedeutet werden. Schreibe natürliches Deutsch und verwende
niemals interne Feldnamen wie horizontal_push, max_strength oder snake_case-Begriffe.

READINESS-GATING HAT HÖCHSTE PRIORITÄT:
- status=low: Empfehle Pause/Regeneration bzw. sehr leichte Aktivität. KEINE zusätzlichen
  Trainingsreize, Finisher oder Zusatzübungen in den Fachbereichen.
- status=moderate/medium/caution: Empfehle reduzierte Intensität/Umfang. Fachliche Lücken
  dürfen benannt werden, aber Zusatzreize nur als später aufzugreifende Themen; keine
  anstrengenden Zusatzblöcke für die nächste Einheit.
- status=high: Kleine konkrete Ergänzungen sind erlaubt, wenn deterministische Fakten
  tatsächlich eine Unterrepräsentation zeigen.

ALLGEMEINER STATUS:
- Beginne mit Trainingshäufigkeit/Trainingsrhythmus und Readiness.
- Wenn days_since_last_workout >= 7, nenne die Zahl ausdrücklich.
- Movement-Recency ist niemals eine Trainingspause.

FACHBEREICHE:
1. Bewegungsmuster
2. Muskelgruppen
3. Trainingsziele
4. Belastungsarten
5. CrossFit-Movements NUR wenn SPORTART CrossFit ist und CrossFit-Daten vorhanden sind.

Für jeden Fachbereich:
- 2 bis 4 Sätze, keine Bulletpoints.
- Erst Gesamtbild einordnen, dann nur echte deterministische Lücken ansprechen.
- Wenn alles ausreichend/ausgewogen ist: ausdrücklich sagen, dass aktuell keine Ergänzung nötig ist.
- Bei status=high darfst du für eine echte Lücke 1–2 einfache, übliche Übungsbeispiele als
  optionale kleine Ergänzung nennen (z. B. nach einer ohnehin geplanten Einheit). Erfinde
  keine Diagnose, kein Defizit und keinen kompletten Trainingsplan.
- Empfehlungen zwischen Bereichen koordinieren: Eine Übung, die bereits eine Bewegungsmuster-
  und Muskelgruppenlücke adressiert, nicht als zweiten zusätzlichen Block duplizieren.
- Belastungsarten nur anhand der vorhandenen Verteilung einordnen; wenn keine deterministische
  Unterrepräsentation ausgewiesen ist, keine künstliche Lücke erfinden.

AUSGABEFORMAT – exakt diese Tags, nichts davor oder danach:
<READINESS_SUMMARY>Ein kurzer Satz nur zu Overload-Signalen.</READINESS_SUMMARY>
<STATUS>Kurzer Coachtext zu Trainingshäufigkeit, letzter Einheit und Readiness.</STATUS>
<MOVEMENT_PATTERNS>Coachtext.</MOVEMENT_PATTERNS>
<MUSCLE_GROUPS>Coachtext.</MUSCLE_GROUPS>
<TRAINING_GOALS>Coachtext.</TRAINING_GOALS>
<LOAD_TYPES>Coachtext.</LOAD_TYPES>
<CROSSFIT_MOVEMENTS>Coachtext oder leer, wenn nicht CrossFit.</CROSSFIT_MOVEMENTS>
""".strip()

    response = call_mistral(api_key=api_key, model=model, content=prompt)

    sections = {
        "status": _extract_section(response, "<STATUS>", "</STATUS>"),
        "movement_patterns": _extract_section(response, "<MOVEMENT_PATTERNS>", "</MOVEMENT_PATTERNS>"),
        "muscle_groups": _extract_section(response, "<MUSCLE_GROUPS>", "</MUSCLE_GROUPS>"),
        "training_goals": _extract_section(response, "<TRAINING_GOALS>", "</TRAINING_GOALS>"),
        "load_types": _extract_section(response, "<LOAD_TYPES>", "</LOAD_TYPES>"),
        "crossfit_movements": _extract_section(response, "<CROSSFIT_MOVEMENTS>", "</CROSSFIT_MOVEMENTS>"),
    }
    readiness_summary = _extract_section(response, "<READINESS_SUMMARY>", "</READINESS_SUMMARY>")
    required = ("status", "movement_patterns", "muscle_groups", "training_goals", "load_types")
    if not readiness_summary or any(not sections[key] for key in required):
        raise RuntimeError("Modulare Coach-Einordnung konnte nicht vollständig aus der Mistral-Antwort gelesen werden.")

    # Persistierbares Format: Überschriften machen auch ältere gespeicherte Texte weiter darstellbar.
    labels = (
        ("Trainingsstatus", "status"),
        ("Bewegungsmuster", "movement_patterns"),
        ("Muskelgruppen", "muscle_groups"),
        ("Trainingsziele", "training_goals"),
        ("Belastungsarten", "load_types"),
        ("CrossFit-Movements", "crossfit_movements"),
    )
    coach_feedback = "\n\n".join(
        f"## {label}\n{sections[key]}" for label, key in labels if sections.get(key)
    )
    return {"readiness_summary": readiness_summary, "coach_feedback": coach_feedback}

def build_daily_coach_tips(
    *,
    readiness: dict,
    weekly_focus: dict,
    training_analysis: TrainingAnalysis,
    history_summary: dict,
    sportart: str,
    level: str,
    injuries: str | None,
    api_key: str,
    model: str,
) -> dict[str, str]:
    """
    Erstellt drei kompakte Daily-Coach-Tipps:
    Training, Ernährung und Recovery.
    """

    prompt = f"""
{DAILY_COACH_TIPS_PROMPT}

SPORTART
{sportart}

LEVEL
{level}

BESCHWERDEN
{injuries or "Keine"}

---

READINESS

{json.dumps(
    readiness,
    ensure_ascii=False,
    indent=2,
)}

---

WEEKLY FOCUS

{json.dumps(
    weekly_focus,
    ensure_ascii=False,
    indent=2,
)}

---

TRAINING ANALYSIS

{json.dumps(
    training_analysis.to_dict(),
    ensure_ascii=False,
    indent=2,
)}

---

HISTORY SUMMARY

{json.dumps(
    history_summary,
    ensure_ascii=False,
    indent=2,
)}
""".strip()

    response = call_mistral(
        api_key=api_key,
        model=model,
        content=prompt,
    )

    response = _remove_code_fence(
        response
    )

    try:
        data = json.loads(
            response
        )

    except json.JSONDecodeError:

        repair_prompt = f"""
Die folgende Antwort sollte ein gültiges JSON-Objekt sein,
enthält aber einen JSON-Syntaxfehler.

Korrigiere ausschließlich die JSON-Syntax.

Verändere keine Inhalte.
Ergänze keine Informationen.
Entferne keine Informationen.

Liefere ausschließlich gültiges JSON.
Kein Markdown.
Keine Code-Fences.
Keine Erklärung.

Fehlerhafte Antwort:

{response}
""".strip()

        repaired_response = call_mistral(
            api_key=api_key,
            model=model,
            content=repair_prompt,
        )

        repaired_response = _remove_code_fence(
            repaired_response
        )

        try:
            data = json.loads(
                repaired_response
            )

        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "Daily Coach Tips konnten nicht als "
                "gültiges JSON verarbeitet werden."
            ) from exc

    if not isinstance(
        data,
        dict,
    ):
        raise RuntimeError(
            "Daily Coach Tips haben ein "
            "unerwartetes Format."
        )

    return {
        "training": str(
            data.get(
                "training",
                "",
            )
        ).strip(),
        "nutrition": str(
            data.get(
                "nutrition",
                "",
            )
        ).strip(),
        "recovery": str(
            data.get(
                "recovery",
                "",
            )
        ).strip(),
    }



def _extract_section(
    text: str,
    start_tag: str,
    end_tag: str,
) -> str:
    value = str(text or "").strip()

    start = value.find(start_tag)
    if start == -1:
        return ""

    start += len(start_tag)
    end = value.find(end_tag, start)

    if end == -1:
        return value[start:].strip()

    return value[start:end].strip()

def _remove_code_fence(
    response: str,
) -> str:
    """
    Entfernt mögliche Markdown-Code-Fences
    aus einer Mistral-Antwort.
    """

    text = str(
        response or ""
    ).strip()

    if text.startswith("```"):
        lines = text.splitlines()

        if lines:
            lines = lines[1:]

        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]

        text = "\n".join(
            lines
        ).strip()

    return text